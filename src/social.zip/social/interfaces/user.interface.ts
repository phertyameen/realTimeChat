export interface GoogleInterface {
    email: string
    firstName: string
    lastName: string
    googleId: string
}